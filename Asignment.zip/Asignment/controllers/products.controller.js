exports.list = (req, res, next) => {
    res.render('products/list_product.ejs');
}
