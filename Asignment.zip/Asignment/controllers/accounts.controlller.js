exports.list = (req, res, next) => {
    res.render('accounts/list_account.ejs');
}
